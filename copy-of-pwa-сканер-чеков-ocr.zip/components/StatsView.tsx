import React, { useMemo } from 'react';
import { Transaction, Category } from '../types';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface StatsViewProps {
  transactions: Transaction[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF1943'];

const StatsView: React.FC<StatsViewProps> = ({ transactions }) => {
  const dataByCategory = useMemo(() => {
    const categoryTotals = transactions.reduce((acc, t) => {
      // FIX: Explicitly convert amount to a number to prevent type errors in arithmetic operations.
      acc[t.category] = (acc[t.category] || 0) + Number(t.amount);
      return acc;
    }, {} as Record<Category, number>);

    return Object.entries(categoryTotals)
      .map(([name, value]) => ({ name, value }))
      // FIX: Explicitly cast values to number to ensure the subtraction operation is valid for TypeScript.
      .sort((a, b) => Number(b.value) - Number(a.value));
  }, [transactions]);

  const totalSpent = useMemo(() => {
    // FIX: Explicitly convert amount to a number to prevent type errors in arithmetic operations.
    return transactions.reduce((sum, t) => sum + Number(t.amount), 0);
  }, [transactions]);
  
  if (transactions.length === 0) {
    return (
        <div className="text-center py-10">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Статистика расходов</h1>
            <p className="text-gray-500 dark:text-gray-400">Нет данных для отображения. Добавьте транзакции, чтобы увидеть статистику.</p>
        </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-center text-gray-900 dark:text-white">Статистика расходов</h1>
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md text-center">
        <p className="text-gray-500 dark:text-gray-400">Общие расходы</p>
        <p className="text-4xl font-bold text-green-600 dark:text-green-400">
            {totalSpent.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 p-2 sm:p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-bold text-center mb-4">Расходы по категориям</h2>
        <div style={{ width: '100%', height: 300 }}>
             <ResponsiveContainer>
                <PieChart>
                    <Pie
                        data={dataByCategory}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                        {dataByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => [`${value.toLocaleString('ru-RU')} ₽`, 'Сумма']} />
                    <Legend />
                </PieChart>
            </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default StatsView;