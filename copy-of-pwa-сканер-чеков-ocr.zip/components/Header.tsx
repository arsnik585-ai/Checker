
import React from 'react';
import { ScanIcon } from './icons/ScanIcon';
import { HistoryIcon } from './icons/HistoryIcon';
import { ChartIcon } from './icons/ChartIcon';

type View = 'scan' | 'history' | 'stats';

interface HeaderProps {
  currentView: View;
  setCurrentView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setCurrentView }) => {
  const navItems = [
    { id: 'scan', label: 'Сканер', icon: <ScanIcon /> },
    { id: 'history', label: 'История', icon: <HistoryIcon /> },
    { id: 'stats', label: 'Статистика', icon: <ChartIcon /> },
  ] as const;

  return (
    <header className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg">
      <nav className="flex justify-around items-center h-16">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`flex flex-col items-center justify-center w-full transition-colors duration-200 ${
              currentView === item.id
                ? 'text-blue-500 dark:text-blue-400'
                : 'text-gray-500 dark:text-gray-400 hover:text-blue-500 dark:hover:text-blue-400'
            }`}
          >
            <div className="w-6 h-6">{item.icon}</div>
            <span className="text-xs font-medium mt-1">{item.label}</span>
          </button>
        ))}
      </nav>
    </header>
  );
};

export default Header;
