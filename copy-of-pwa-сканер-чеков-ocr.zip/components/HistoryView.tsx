
import React, { useState } from 'react';
import { Transaction, Category } from '../types';

interface HistoryViewProps {
  transactions: Transaction[];
  deleteTransaction: (id: string) => void;
  updateTransaction: (transaction: Transaction) => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ transactions, deleteTransaction, updateTransaction }) => {
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const handleUpdate = () => {
    if (editingTransaction) {
      updateTransaction(editingTransaction);
      setEditingTransaction(null);
    }
  };

  if (transactions.length === 0) {
    return (
      <div className="text-center py-10">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">История транзакций</h1>
        <p className="text-gray-500 dark:text-gray-400">Вы еще не добавили ни одной транзакции. Начните со сканирования чека!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-center text-gray-900 dark:text-white">История транзакций</h1>
      <div className="space-y-4">
        {transactions.map(t => (
          <div key={t.id} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-bold text-lg">{t.store}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{new Date(t.date).toLocaleDateString('ru-RU')}</p>
                <p className="text-sm bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300 inline-block px-2 py-0.5 rounded-full mt-1">{t.category}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-xl text-green-600 dark:text-green-400">{t.amount.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}</p>
                <div className="flex gap-2 mt-2">
                  <button onClick={() => setEditingTransaction(t)} className="text-sm text-blue-500 hover:underline">Изменить</button>
                  <button onClick={() => deleteTransaction(t.id)} className="text-sm text-red-500 hover:underline">Удалить</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {editingTransaction && (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md space-y-4">
                <h2 className="text-xl font-bold">Редактировать транзакцию</h2>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Магазин</label>
                    <input type="text" value={editingTransaction.store} onChange={(e) => setEditingTransaction({...editingTransaction, store: e.target.value})} className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Сумма</label>
                    <input type="number" value={editingTransaction.amount} onChange={(e) => setEditingTransaction({...editingTransaction, amount: parseFloat(e.target.value) || 0})} className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Дата</label>
                    <input type="date" value={editingTransaction.date} onChange={(e) => setEditingTransaction({...editingTransaction, date: e.target.value})} className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Категория</label>
                    <select value={editingTransaction.category} onChange={(e) => setEditingTransaction({...editingTransaction, category: e.target.value as Category})} className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3">
                      {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                </div>
                <div className="flex justify-end gap-4">
                    <button onClick={() => setEditingTransaction(null)} className="px-4 py-2 bg-gray-300 text-gray-800 font-semibold rounded-lg hover:bg-gray-400 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">Отмена</button>
                    <button onClick={handleUpdate} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">Сохранить</button>
                </div>
            </div>
         </div>
      )}
    </div>
  );
};

export default HistoryView;
