
import { GoogleGenAI, Type } from "@google/genai";
import { Category } from '../types.ts';

// Безопасное получение ключа, чтобы не уронить всё приложение на этапе инициализации
const getApiKey = () => {
    try {
        if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
            return process.env.API_KEY;
        }
    } catch (e) {}
    return null;
};

const API_KEY = getApiKey();

if (!API_KEY) {
    console.warn("API_KEY not found. Analysis features will be disabled.");
}

// Ленивая инициализация AI, если ключ есть
const getAiInstance = () => {
    const key = getApiKey();
    if (!key) return null;
    return new GoogleGenAI({ apiKey: key });
};

const modelName = "gemini-3-flash-preview";

export const categorizeTransaction = async (ocrText: string): Promise<{ store: string; amount: number; date: string; category: Category }> => {
    const ai = getAiInstance();
    if (!ai) {
        return {
            store: 'Ошибка: API ключ не настроен',
            amount: 0,
            date: new Date().toISOString().split('T')[0],
            category: Category.Other,
        };
    }

    const categories = Object.values(Category).join(', ');
    const prompt = `Проанализируй текст чека и верни JSON: {store, amount, date (YYYY-MM-DD), category}. Категории: ${categories}. Текст: ${ocrText}`;

    try {
        const response = await ai.models.generateContent({
            model: modelName,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        store: { type: Type.STRING },
                        amount: { type: Type.NUMBER },
                        date: { type: Type.STRING },
                        category: { type: Type.STRING, enum: Object.values(Category) },
                    },
                    required: ["store", "amount", "date", "category"]
                }
            }
        });

        const parsed = JSON.parse(response.text || '{}');

        return {
            store: parsed.store || 'Неизвестный магазин',
            amount: parsed.amount || 0,
            date: parsed.date || new Date().toISOString().split('T')[0],
            category: Object.values(Category).includes(parsed.category as Category) ? (parsed.category as Category) : Category.Other,
        };

    } catch (error) {
        console.error("Gemini Error:", error);
        return {
            store: 'Ошибка анализа',
            amount: 0,
            date: new Date().toISOString().split('T')[0],
            category: Category.Other,
        };
    }
};
