
import React, { useState, useRef } from 'react';
import { Transaction, Category } from '../types.ts';
import { categorizeTransaction } from '../services/geminiService.ts';
import { CameraIcon } from './icons/CameraIcon.tsx';
import { UploadIcon } from './icons/UploadIcon.tsx';

// This is to inform TypeScript about the Tesseract object available globally from the CDN
declare const Tesseract: any;

interface ScanViewProps {
  addTransaction: (transaction: Transaction) => void;
}

const ScanView: React.FC<ScanViewProps> = ({ addTransaction }) => {
  const [image, setImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrStatus, setOcrStatus] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [rawText, setRawText] = useState('');
  const [editedTransaction, setEditedTransaction] = useState<Omit<Transaction, 'id' | 'rawText' | 'imageSrc'> | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setRawText('');
        setEditedTransaction(null);
        processImage(file);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async (file: File) => {
    setIsProcessing(true);
    setOcrProgress(0);
    setOcrStatus('Инициализация...');

    try {
      const worker = await Tesseract.createWorker('rus+eng', 1, {
        logger: (m: any) => {
          if (m.status === 'recognizing text') {
              setOcrStatus('Распознавание текста...');
              setOcrProgress(Math.round(m.progress * 100));
          } else {
              setOcrStatus(m.status);
          }
        },
      });

      const { data: { text } } = await worker.recognize(file);
      setRawText(text);
      setOcrStatus('Анализ данных с помощью AI...');
      setOcrProgress(100);

      const parsedData = await categorizeTransaction(text);
      setEditedTransaction(parsedData);
      
      await worker.terminate();
    } catch (err) {
      console.error("OCR Error:", err);
      setOcrStatus('Ошибка при распознавании');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = () => {
    if (editedTransaction && image) {
      addTransaction({
        ...editedTransaction,
        id: new Date().toISOString(),
        rawText,
        imageSrc: image,
      });
      resetState();
    }
  };

  const resetState = () => {
      setImage(null);
      setImageFile(null);
      setOcrProgress(0);
      setOcrStatus('');
      setIsProcessing(false);
      setRawText('');
      setEditedTransaction(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (cameraInputRef.current) cameraInputRef.current.value = '';
  }

  const handleFieldChange = (field: keyof Omit<Transaction, 'id' | 'rawText' | 'imageSrc'>, value: string | number | Category) => {
    if (editedTransaction) {
      setEditedTransaction({ ...editedTransaction, [field]: value });
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Сканер чеков</h1>
        <p className="text-sm text-gray-500 mt-1">Загрузите фото для автоматического учета</p>
      </div>
      
      {!image && (
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <button onClick={() => fileInputRef.current?.click()} className="flex items-center justify-center gap-3 w-full sm:w-auto px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all active:scale-95">
                <UploadIcon /> Загрузить файл
            </button>
            <button onClick={() => cameraInputRef.current?.click()} className="flex items-center justify-center gap-3 w-full sm:w-auto px-6 py-4 bg-gradient-to-r from-green-600 to-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all active:scale-95">
                <CameraIcon /> Сделать фото
            </button>
            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageChange} className="hidden" />
            <input type="file" accept="image/*" capture="environment" ref={cameraInputRef} onChange={handleImageChange} className="hidden" />
        </div>
      )}

      {isProcessing && (
         <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center z-50">
            <div className="w-20 h-20 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
            <p className="text-white text-lg font-medium mt-6">{ocrStatus}</p>
            {ocrProgress > 0 && ocrProgress < 100 && (
                <div className="w-64 bg-gray-700 rounded-full h-2 mt-4 overflow-hidden">
                    <div className="bg-blue-500 h-full transition-all duration-300" style={{ width: `${ocrProgress}%` }}></div>
                </div>
            )}
         </div>
      )}

      {image && !isProcessing && editedTransaction && (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl space-y-6 animate-fade-in border border-gray-100 dark:border-gray-700">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                Изображение чека
              </h2>
              <div className="relative group">
                <img src={image} alt="Чек" className="rounded-xl max-h-96 w-full object-contain bg-gray-50 dark:bg-gray-900 p-2" />
              </div>
            </div>
            <div className="space-y-4">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Данные чека
                </h2>
                <div className="grid gap-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Магазин</label>
                        <input type="text" value={editedTransaction.store} onChange={(e) => handleFieldChange('store', e.target.value)} className="w-full bg-gray-50 dark:bg-gray-700 border-none rounded-lg py-3 px-4 focus:ring-2 focus:ring-blue-500" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Сумма (₽)</label>
                            <input type="number" value={editedTransaction.amount} onChange={(e) => handleFieldChange('amount', parseFloat(e.target.value) || 0)} className="w-full bg-gray-50 dark:bg-gray-700 border-none rounded-lg py-3 px-4 focus:ring-2 focus:ring-blue-500" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Дата</label>
                            <input type="date" value={editedTransaction.date} onChange={(e) => handleFieldChange('date', e.target.value)} className="w-full bg-gray-50 dark:bg-gray-700 border-none rounded-lg py-3 px-4 focus:ring-2 focus:ring-blue-500" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Категория</label>
                        <select value={editedTransaction.category} onChange={(e) => handleFieldChange('category', e.target.value as Category)} className="w-full bg-gray-50 dark:bg-gray-700 border-none rounded-lg py-3 px-4 focus:ring-2 focus:ring-blue-500">
                          {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                </div>
            </div>
          </div>
          <div className="pt-6 border-t dark:border-gray-700 flex justify-end gap-3">
            <button onClick={resetState} className="px-6 py-2.5 bg-gray-100 text-gray-600 font-semibold rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 transition-colors">Отмена</button>
            <button onClick={handleSave} className="px-8 py-2.5 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 shadow-md shadow-blue-500/20 transition-all active:scale-95">Сохранить</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScanView;
